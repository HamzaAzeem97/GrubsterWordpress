=== Bunyad Widget for Instagram ===
Requires PHP: 5.4